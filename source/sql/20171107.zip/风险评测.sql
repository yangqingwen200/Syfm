/*
SQLyog Ultimate v11.13 (64 bit)
MySQL - 5.6.30 : Database - systemframework
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`systemframework` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `systemframework`;

/*Table structure for table `sys_menu_1` */

DROP TABLE IF EXISTS `sys_menu_1`;

CREATE TABLE `sys_menu_1` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '菜单表',
  `name` varchar(20) CHARACTER SET gbk NOT NULL COMMENT '菜单名称',
  `path` varchar(150) CHARACTER SET gbk NOT NULL COMMENT '菜单功能路径',
  `remark` varchar(50) CHARACTER SET gbk NOT NULL COMMENT '备注,配合前台加当前选中样式',
  `disploy` int(1) NOT NULL DEFAULT '1' COMMENT '是否显示',
  `parent` int(4) NOT NULL DEFAULT '0' COMMENT '父菜单id,父菜单默认为0',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `remark` (`remark`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_bin CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

/*Data for the table `sys_menu_1` */

insert  into `sys_menu_1`(`id`,`name`,`path`,`remark`,`disploy`,`parent`,`create_time`) values (1,'主页','/','index',1,0,'2017-11-06 09:59:14'),(2,'预约培训','/business/onestop/list.html','business',1,0,'2017-11-06 10:00:17'),(3,'一站式拿证','/business/onestop/list.html','onestop',1,2,'2017-11-06 10:03:00'),(4,'计时学车','/business/time/list.html','time',1,2,'2017-11-06 10:03:15'),(5,'科目二套餐','/business/keer/list.html','keer',1,2,'2017-11-06 10:03:45'),(6,'科目三套餐','/business/kesan/list.html','kesan',1,2,'2017-11-06 10:04:03');

/*Table structure for table `sys_permission_1` */

DROP TABLE IF EXISTS `sys_permission_1`;

CREATE TABLE `sys_permission_1` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '许可表',
  `permission` varchar(20) CHARACTER SET gbk NOT NULL COMMENT '许可名',
  `remark` varchar(50) CHARACTER SET gbk DEFAULT NULL COMMENT '备注',
  `code` varchar(100) CHARACTER SET gbk NOT NULL COMMENT '许可代码',
  `parent` int(4) NOT NULL DEFAULT '0' COMMENT '父许可id，对应表permission.id',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

/*Data for the table `sys_permission_1` */

insert  into `sys_permission_1`(`id`,`permission`,`remark`,`code`,`parent`) values (1,'一站式拿证列表','123','onestop/list',4),(2,'新增一站式拿证',NULL,'onestop/adds',4),(3,'删除一站式拿证',NULL,'onestop/delete',4),(4,'buiness',NULL,'buiness',0),(5,'编辑一站式拿证',NULL,'onestop/edit',4),(6,'index',NULL,'index#',0),(9,'首页',NULL,'index',6),(10,'科三列表',NULL,'kesan/list',4);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
